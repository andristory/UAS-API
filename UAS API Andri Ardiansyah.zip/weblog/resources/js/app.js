const popper    = require('@popperjs/core');
const bootsrap  = require('bootstrap');
const tinymce   = require('tinymce');

require('tinymce/themes/silver');
require('tinymce/icons/default');