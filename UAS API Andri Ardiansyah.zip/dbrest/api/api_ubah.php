<?php 
require_once('../config/koneksi.php');
    if (isset($_POST['id'])) {
        $id                 = $_POST['id'];
        $npm                = $_POST['npm'];
        $nama               = $_POST['nama'];
        $email              = $_POST['email'];
        $jurusan            = $_POST['jurusan'];
        $sql = $conn->prepare("UPDATE mahasiswa SET npm=?, nama=?, email=?, jurusan=? WHERE id=?");
        $sql->bind_param('ssddd', $npm, $nama, $email, $jurusan, $id);
        $sql->execute();
        if ($sql) {
        //echo json_encode(array('RESPONSE' => 'SUCCESS'));
        header("location:../readapi/tampil.php");
        echo json_encode(array('RESPONSE' => 'FAILED'));
        }else {
            echo "GAGAL";
        }   
    } else {
    
    }

?>