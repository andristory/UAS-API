<?php
    require_once('../config/koneksi.php');
    if (isset($_POST['npm']) && isset($_POST['nama']) && isset($_POST['email']) && isset($_POST['jurusan'])) {
        $nama_produk    = $_POST['npm'];
        $tipe_produk  = $_POST['nama'];
        $sql = $conn->prepare("INSERT INTO mahasiswa (npm, nama, email, jurusan) VALUES (?, ?, ?, ?)");
        $harga    = $_POST['email'];
        $stok    = $_POST['jurusan'];
        $sql->bind_param('ssdd', $npm, $nama, $email, $jurusan);
        $sql->execute();
        if ($sql) {
         echo json_encode(array('RESPONSE' => 'FAILED'));
         //echo json_encode(array('RESPONSE' => 'SUCCESS'));
         header("location:../readapi/tampil.php");
        } else {
        
        }
    } else {
        echo "GAGAL";
    }
?>